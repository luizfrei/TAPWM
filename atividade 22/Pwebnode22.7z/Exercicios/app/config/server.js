var expreess = require('express');
var app=expreess(); //executando o express
app.set('view engine','ejs');
app.set('view','./app/viewa');

module.exports = app;
