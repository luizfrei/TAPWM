﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasse
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Horista ObjHorista = new Horista();

            ObjHorista.NomeEmpregado = txtNome.Text;
            ObjHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            ObjHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            ObjHorista.NumeroHora = Convert.ToDouble(txtHora.Text);
            ObjHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            ObjHorista.DiasFalta = Convert.ToInt32(txtFalta.Text);

            MessageBox.Show("Nome" + ObjHorista.NomeEmpregado +
                            "\n" + "Matricula:" + ObjHorista.Matricula + "\n" +
                            "Tempo Trabalho:" + ObjHorista.TempoTrabalho().ToString() + "\n"
                            + "Salário:" + ObjHorista.SalarioBruto().ToString("N2"));

            MessageBox.Show($"Salário Com Aumento: {ObjHorista.SalarioBruto(50).ToString("N2")}");
        }
    }
}
